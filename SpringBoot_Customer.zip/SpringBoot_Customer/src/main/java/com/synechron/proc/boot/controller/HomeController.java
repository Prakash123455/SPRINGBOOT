package com.synechron.proc.boot.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.synechron.proc.boot.model.Customer;
import com.synechron.proc.boot.service.CustomerService;

@RestController
public class HomeController {

	@Autowired
	CustomerService customerService;

	
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ModelAndView CustomerHome(HttpServletRequest req, HttpServletResponse res) {
		ModelAndView mv = new ModelAndView("Customers_1");
		return mv;
	}
	@RequestMapping(value = "/customer", method = RequestMethod.POST)
	public ModelAndView CustomerAdded(HttpServletRequest req, HttpServletResponse res,
			@ModelAttribute("customer") Customer customer)
	{
		System.out.println("customer adding...");
		ModelAndView mv = null;
		try {
			boolean isSaveCustomers = customerService.addCustomer(customer);
			// System.out.println("CUSTOMER IS SAVED OR NOT:-" + isSaveCustomers);
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		mv = new ModelAndView("Customers_2");
		List<Customer> customerlist = customerService.getAllCustomer();
		mv.addObject("customerlistDetailsList", customerlist);
		return mv;
	}
	
	@RequestMapping(value = "/editcustomer/{customerId}", method = RequestMethod.GET)
	public ModelAndView editCustomer(HttpServletRequest req, HttpServletResponse res,
			@PathVariable("customerId") int customerId,
			@ModelAttribute("insuranceplandetails") Customer insuranceplandetails) {
		
//		Customer insplanbyId = null;
	ModelAndView mv = new ModelAndView("Customers_3");
//		try {
//			insplanbyId = customerService.getCustomer(customerId);
//	System.out.println("-------xxXX----" + insplanbyId);
//		} 
//		catch (Exception e) 
//		{
//			e.printStackTrace();
//		}
//		if (insplanbyId != null) {
//			mv.addObject("insplanbyId", insplanbyId);
//			List<Customer> insurancePlanDetailsList = customerService.getAllCustomer();
//			mv.addObject("JspPlanDetailsList", insurancePlanDetailsList);
//
//		}
	return mv;
	}
	
	@RequestMapping(value = "/editcustomerupdate", method = RequestMethod.POST)
	public ModelAndView editCustomerUpdate(HttpServletRequest req, HttpServletResponse res,
			@ModelAttribute("customer") Customer customer) 
	{
		int idOfCustomer=Integer.parseInt(req.getParameter("inputName"));
		ModelAndView mv = new ModelAndView("Customers_2");
		boolean isSavePlan ;
		try {
			isSavePlan = customerService.updateCustomer(idOfCustomer,customer);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return mv;
	}
	
}
