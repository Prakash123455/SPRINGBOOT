package com.sujata.presentation;

public interface CustomerUI {

	public void showMenu();
	public void perform(int choice);
}
